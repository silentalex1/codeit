import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Server, Wifi, WifiOff, Key, Zap, Code, Save, TestTube, AlertCircle, CheckCircle2, Settings as SettingsIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useWebSocket } from '@/hooks/useWebSocket';
import { ConnectionStatus } from '@/lib/index';
import { fadeInUp, staggerContainer, staggerItem, springPresets } from '@/lib/motion';

interface SettingsConfig {
  serverUrl: string;
  apiKey: string;
  autoReconnect: boolean;
  reconnectDelay: number;
  maxReconnectAttempts: number;
  enableNotifications: boolean;
  darkMode: boolean;
  codeTheme: string;
  autoSave: boolean;
  autoSaveInterval: number;
}

const DEFAULT_SETTINGS: SettingsConfig = {
  serverUrl: 'ws://localhost:8080',
  apiKey: '',
  autoReconnect: true,
  reconnectDelay: 1000,
  maxReconnectAttempts: 5,
  enableNotifications: true,
  darkMode: true,
  codeTheme: 'monokai',
  autoSave: true,
  autoSaveInterval: 30000,
};

export default function Settings() {
  const [settings, setSettings] = useState<SettingsConfig>(() => {
    const saved = localStorage.getItem('roblox-ai-settings');
    return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
  });
  const [testUrl, setTestUrl] = useState(settings.serverUrl);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [hasChanges, setHasChanges] = useState(false);

  const { status, connect, disconnect } = useWebSocket(settings.serverUrl);

  useEffect(() => {
    localStorage.setItem('roblox-ai-settings', JSON.stringify(settings));
  }, [settings]);

  const updateSetting = <K extends keyof SettingsConfig>(key: K, value: SettingsConfig[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const handleSave = () => {
    localStorage.setItem('roblox-ai-settings', JSON.stringify(settings));
    setHasChanges(false);
    if (settings.serverUrl !== testUrl) {
      disconnect();
      setTimeout(() => connect(), 100);
    }
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);

    try {
      const testWs = new WebSocket(testUrl);
      
      const timeout = setTimeout(() => {
        testWs.close();
        setTestResult({ success: false, message: 'Connection timeout' });
        setIsTesting(false);
      }, 5000);

      testWs.onopen = () => {
        clearTimeout(timeout);
        setTestResult({ success: true, message: 'Connection successful' });
        testWs.close();
        setIsTesting(false);
      };

      testWs.onerror = () => {
        clearTimeout(timeout);
        setTestResult({ success: false, message: 'Connection failed' });
        setIsTesting(false);
      };
    } catch (error) {
      setTestResult({ success: false, message: 'Invalid URL or connection error' });
      setIsTesting(false);
    }
  };

  const handleReset = () => {
    setSettings(DEFAULT_SETTINGS);
    setTestUrl(DEFAULT_SETTINGS.serverUrl);
    setHasChanges(true);
  };

  const getStatusColor = () => {
    switch (status) {
      case ConnectionStatus.CONNECTED:
        return 'text-green-500';
      case ConnectionStatus.CONNECTING:
        return 'text-yellow-500';
      case ConnectionStatus.ERROR:
        return 'text-red-500';
      default:
        return 'text-muted-foreground';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case ConnectionStatus.CONNECTED:
        return <Wifi className="w-4 h-4" />;
      case ConnectionStatus.CONNECTING:
        return <Zap className="w-4 h-4 animate-pulse" />;
      default:
        return <WifiOff className="w-4 h-4" />;
    }
  };

  return (
    <motion.div
      variants={staggerContainer}
      initial="hidden"
      animate="visible"
      className="min-h-screen bg-background p-6"
    >
      <div className="max-w-5xl mx-auto space-y-6">
        <motion.div variants={fadeInUp} className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold tracking-tight flex items-center gap-3">
              <SettingsIcon className="w-10 h-10 text-primary" />
              Settings
            </h1>
            <p className="text-muted-foreground mt-2">
              Configure your Roblox AI Game Builder connection and preferences
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className={`${getStatusColor()} border-current`}>
              <span className="flex items-center gap-2">
                {getStatusIcon()}
                {status}
              </span>
            </Badge>
            {hasChanges && (
              <Button onClick={handleSave} size="lg" className="gap-2">
                <Save className="w-4 h-4" />
                Save Changes
              </Button>
            )}
          </div>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Tabs defaultValue="connection" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="connection">Connection</TabsTrigger>
              <TabsTrigger value="preferences">Preferences</TabsTrigger>
              <TabsTrigger value="advanced">Advanced</TabsTrigger>
            </TabsList>

            <TabsContent value="connection" className="space-y-6 mt-6">
              <motion.div variants={staggerItem}>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Server className="w-5 h-5 text-primary" />
                      WebSocket Server
                    </CardTitle>
                    <CardDescription>
                      Configure the WebSocket server URL for plugin communication
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="serverUrl">Server URL</Label>
                      <div className="flex gap-2">
                        <Input
                          id="serverUrl"
                          value={testUrl}
                          onChange={(e) => {
                            setTestUrl(e.target.value);
                            updateSetting('serverUrl', e.target.value);
                          }}
                          placeholder="ws://localhost:8080"
                          className="font-mono"
                        />
                        <Button
                          onClick={handleTestConnection}
                          disabled={isTesting}
                          variant="outline"
                          className="gap-2 min-w-[120px]"
                        >
                          <TestTube className="w-4 h-4" />
                          {isTesting ? 'Testing...' : 'Test'}
                        </Button>
                      </div>
                      {testResult && (
                        <motion.div
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={springPresets.snappy}
                          className={`flex items-center gap-2 text-sm ${
                            testResult.success ? 'text-green-500' : 'text-red-500'
                          }`}
                        >
                          {testResult.success ? (
                            <CheckCircle2 className="w-4 h-4" />
                          ) : (
                            <AlertCircle className="w-4 h-4" />
                          )}
                          {testResult.message}
                        </motion.div>
                      )}
                    </div>

                    <Separator />

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Auto Reconnect</Label>
                          <p className="text-sm text-muted-foreground">
                            Automatically reconnect on connection loss
                          </p>
                        </div>
                        <Switch
                          checked={settings.autoReconnect}
                          onCheckedChange={(checked) => updateSetting('autoReconnect', checked)}
                        />
                      </div>

                      {settings.autoReconnect && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          transition={springPresets.gentle}
                          className="space-y-4 pl-4 border-l-2 border-primary/20"
                        >
                          <div className="space-y-2">
                            <Label htmlFor="reconnectDelay">Reconnect Delay (ms)</Label>
                            <Input
                              id="reconnectDelay"
                              type="number"
                              value={settings.reconnectDelay}
                              onChange={(e) => updateSetting('reconnectDelay', parseInt(e.target.value))}
                              min={100}
                              max={10000}
                              step={100}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="maxAttempts">Max Reconnect Attempts</Label>
                            <Input
                              id="maxAttempts"
                              type="number"
                              value={settings.maxReconnectAttempts}
                              onChange={(e) => updateSetting('maxReconnectAttempts', parseInt(e.target.value))}
                              min={1}
                              max={20}
                            />
                          </div>
                        </motion.div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={staggerItem}>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Key className="w-5 h-5 text-primary" />
                      API Configuration
                    </CardTitle>
                    <CardDescription>
                      Manage API keys and authentication settings
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="apiKey">API Key</Label>
                      <Input
                        id="apiKey"
                        type="password"
                        value={settings.apiKey}
                        onChange={(e) => updateSetting('apiKey', e.target.value)}
                        placeholder="Enter your API key"
                        className="font-mono"
                      />
                      <p className="text-xs text-muted-foreground">
                        Your API key is stored locally and never sent to external servers
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            <TabsContent value="preferences" className="space-y-6 mt-6">
              <motion.div variants={staggerItem}>
                <Card>
                  <CardHeader>
                    <CardTitle>Editor Preferences</CardTitle>
                    <CardDescription>
                      Customize your code editor experience
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Auto Save</Label>
                        <p className="text-sm text-muted-foreground">
                          Automatically save changes while editing
                        </p>
                      </div>
                      <Switch
                        checked={settings.autoSave}
                        onCheckedChange={(checked) => updateSetting('autoSave', checked)}
                      />
                    </div>

                    {settings.autoSave && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        transition={springPresets.gentle}
                        className="space-y-2 pl-4 border-l-2 border-primary/20"
                      >
                        <Label htmlFor="autoSaveInterval">Auto Save Interval (seconds)</Label>
                        <Input
                          id="autoSaveInterval"
                          type="number"
                          value={settings.autoSaveInterval / 1000}
                          onChange={(e) => updateSetting('autoSaveInterval', parseInt(e.target.value) * 1000)}
                          min={5}
                          max={300}
                          step={5}
                        />
                      </motion.div>
                    )}

                    <Separator />

                    <div className="space-y-2">
                      <Label htmlFor="codeTheme">Code Theme</Label>
                      <select
                        id="codeTheme"
                        value={settings.codeTheme}
                        onChange={(e) => updateSetting('codeTheme', e.target.value)}
                        className="w-full px-3 py-2 bg-background border border-input rounded-md"
                      >
                        <option value="monokai">Monokai</option>
                        <option value="github-dark">GitHub Dark</option>
                        <option value="dracula">Dracula</option>
                        <option value="nord">Nord</option>
                        <option value="one-dark">One Dark</option>
                      </select>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={staggerItem}>
                <Card>
                  <CardHeader>
                    <CardTitle>Notifications</CardTitle>
                    <CardDescription>
                      Control notification preferences
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Enable Notifications</Label>
                        <p className="text-sm text-muted-foreground">
                          Receive notifications for important events
                        </p>
                      </div>
                      <Switch
                        checked={settings.enableNotifications}
                        onCheckedChange={(checked) => updateSetting('enableNotifications', checked)}
                      />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            <TabsContent value="advanced" className="space-y-6 mt-6">
              <motion.div variants={staggerItem}>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Code className="w-5 h-5 text-primary" />
                      Developer Options
                    </CardTitle>
                    <CardDescription>
                      Advanced settings for developers
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                      <h4 className="font-semibold text-sm">Current Configuration</h4>
                      <pre className="text-xs font-mono overflow-x-auto">
                        {JSON.stringify(settings, null, 2)}
                      </pre>
                    </div>

                    <Separator />

                    <div className="flex gap-2">
                      <Button onClick={handleReset} variant="outline" className="gap-2">
                        <AlertCircle className="w-4 h-4" />
                        Reset to Defaults
                      </Button>
                      <Button
                        onClick={() => {
                          const dataStr = JSON.stringify(settings, null, 2);
                          const dataBlob = new Blob([dataStr], { type: 'application/json' });
                          const url = URL.createObjectURL(dataBlob);
                          const link = document.createElement('a');
                          link.href = url;
                          link.download = 'roblox-ai-settings.json';
                          link.click();
                          URL.revokeObjectURL(url);
                        }}
                        variant="outline"
                        className="gap-2"
                      >
                        <Save className="w-4 h-4" />
                        Export Settings
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={staggerItem}>
                <Card className="border-yellow-500/20 bg-yellow-500/5">
                  <CardHeader>
                    <CardTitle className="text-yellow-500 flex items-center gap-2">
                      <AlertCircle className="w-5 h-5" />
                      Important Notes
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm text-muted-foreground">
                    <p>• Changes to connection settings require reconnection to take effect</p>
                    <p>• API keys are stored locally in your browser's localStorage</p>
                    <p>• WebSocket connections require the Roblox Studio plugin to be running</p>
                    <p>• Auto-save only applies to code editor changes, not project settings</p>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </motion.div>
  );
}