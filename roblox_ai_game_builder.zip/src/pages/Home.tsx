import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Sparkles, Zap, Code2, Rocket, Users, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { IMAGES } from "@/assets/images";
import { ROUTE_PATHS } from "@/lib/index";
import { fadeInUp, staggerContainer, staggerItem, hoverLift } from "@/lib/motion";

export default function Home() {
  const features = [
    {
      icon: Sparkles,
      title: "AI-Powered Generation",
      description: "Transform natural language prompts into fully functional Roblox games instantly with advanced AI technology.",
    },
    {
      icon: Zap,
      title: "Real-Time Plugin Connectivity",
      description: "Seamless WebSocket connection between your browser and Roblox Studio for instant synchronization.",
    },
    {
      icon: Code2,
      title: "Live Code Editing",
      description: "Edit and preview your game code in real-time with syntax highlighting and intelligent suggestions.",
    },
    {
      icon: Rocket,
      title: "Instant Deployment",
      description: "Deploy changes directly to your Roblox game with one click, no manual file transfers needed.",
    },
    {
      icon: Users,
      title: "Collaborative Workspace",
      description: "Work together with your team in real-time, see changes as they happen across all connected clients.",
    },
    {
      icon: Shield,
      title: "Secure & Reliable",
      description: "Enterprise-grade security with encrypted connections and automatic backup of all your projects.",
    },
  ];

  const stats = [
    { value: "10K+", label: "Games Created" },
    { value: "99.9%", label: "Uptime" },
    { value: "<100ms", label: "Sync Latency" },
    { value: "24/7", label: "Support" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src={IMAGES.TECH_BACKGROUND_1}
            alt=""
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-transparent to-background/70" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
            className="max-w-5xl mx-auto text-center"
          >
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">AI-Powered Roblox Game Builder</span>
            </motion.div>

            <motion.h1
              variants={fadeInUp}
              className="text-6xl md:text-7xl lg:text-8xl font-bold mb-6 bg-gradient-to-br from-foreground via-foreground to-muted-foreground bg-clip-text text-transparent"
            >
              Build Roblox Games
              <br />
              <span className="text-primary">With AI Magic</span>
            </motion.h1>

            <motion.p
              variants={fadeInUp}
              className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-3xl mx-auto"
            >
              Transform your ideas into playable Roblox games instantly. Connect your Studio plugin, describe your vision, and watch AI bring it to life in real-time.
            </motion.p>

            <motion.div variants={fadeInUp} className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="text-lg px-8 py-6">
                <Link to={ROUTE_PATHS.DASHBOARD}>Start Building Now</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="text-lg px-8 py-6">
                <Link to={ROUTE_PATHS.PROJECTS}>View Examples</Link>
              </Button>
            </motion.div>

            <motion.div
              variants={fadeInUp}
              className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20 max-w-4xl mx-auto"
            >
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-4xl md:text-5xl font-bold text-primary mb-2">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
      </section>

      <section className="py-24 relative">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="max-w-3xl mx-auto text-center mb-16"
          >
            <motion.h2 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-6">
              Everything You Need to Build
            </motion.h2>
            <motion.p variants={fadeInUp} className="text-xl text-muted-foreground">
              Professional tools designed for creators who want to build faster and smarter.
            </motion.p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto"
          >
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  variants={staggerItem}
                  whileHover="hover"
                  initial="rest"
                  className="group"
                >
                  <motion.div
                    variants={hoverLift}
                    className="h-full p-8 rounded-2xl bg-card border border-border backdrop-blur-sm transition-all"
                  >
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                  </motion.div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src={IMAGES.AI_INTERFACE_2}
            alt=""
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="max-w-4xl mx-auto text-center"
          >
            <motion.h2 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-6">
              Ready to Transform Your Ideas?
            </motion.h2>
            <motion.p variants={fadeInUp} className="text-xl text-muted-foreground mb-12">
              Join thousands of creators building the next generation of Roblox games with AI assistance.
            </motion.p>
            <motion.div variants={fadeInUp}>
              <Button asChild size="lg" className="text-lg px-12 py-6">
                <Link to={ROUTE_PATHS.DASHBOARD}>
                  <Rocket className="w-5 h-5 mr-2" />
                  Get Started Free
                </Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      <footer className="border-t border-border py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-muted-foreground">
              © 2026 AI Roblox Game Builder. All rights reserved.
            </div>
            <div className="flex gap-6">
              <Link to={ROUTE_PATHS.DASHBOARD} className="text-muted-foreground hover:text-foreground transition-colors">
                Dashboard
              </Link>
              <Link to={ROUTE_PATHS.PROJECTS} className="text-muted-foreground hover:text-foreground transition-colors">
                Projects
              </Link>
              <Link to={ROUTE_PATHS.SETTINGS} className="text-muted-foreground hover:text-foreground transition-colors">
                Settings
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}