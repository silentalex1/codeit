import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Zap, Code, Sparkles, Activity, Clock, Folder } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AIPromptInterface } from '@/components/AIPromptInterface';
import { CodeEditor } from '@/components/CodeEditor';
import { ProjectCard } from '@/components/ProjectCard';
import { useWebSocket } from '@/hooks/useWebSocket';
import { useProjects } from '@/hooks/useProjects';
import { ConnectionStatus, formatTimestamp } from '@/lib/index';
import { fadeInUp, staggerContainer, staggerItem, springPresets } from '@/lib/motion';
import { useNavigate } from 'react-router-dom';
import { ROUTE_PATHS } from '@/lib/index';

export default function Dashboard() {
  const navigate = useNavigate();
  const { status, send, lastMessage } = useWebSocket();
  const { projects, createProject, deleteProject, listProjects } = useProjects();
  const [generatedCode, setGeneratedCode] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [generationHistory, setGenerationHistory] = useState<Array<{
    id: string;
    prompt: string;
    timestamp: Date;
    status: 'pending' | 'completed' | 'error';
  }>>([]);

  const recentProjects = listProjects().slice(0, 3);
  const activeProjects = listProjects({ status: 'active' });

  useEffect(() => {
    if (lastMessage) {
      if (lastMessage.type === 'generation_complete') {
        setGeneratedCode(lastMessage.code || '');
        setIsGenerating(false);
        setGenerationHistory(prev =>
          prev.map(item =>
            item.id === lastMessage.requestId
              ? { ...item, status: 'completed' }
              : item
          )
        );
      } else if (lastMessage.type === 'generation_error') {
        setIsGenerating(false);
        setGenerationHistory(prev =>
          prev.map(item =>
            item.id === lastMessage.requestId
              ? { ...item, status: 'error' }
              : item
          )
        );
      } else if (lastMessage.type === 'code_update') {
        setGeneratedCode(lastMessage.code || '');
      }
    }
  }, [lastMessage]);

  const handleGenerate = (prompt: string) => {
    if (status !== ConnectionStatus.CONNECTED) {
      return;
    }

    const requestId = `gen-${Date.now()}`;
    setIsGenerating(true);
    setGenerationHistory(prev => [
      {
        id: requestId,
        prompt,
        timestamp: new Date(),
        status: 'pending',
      },
      ...prev,
    ]);

    send({
      type: 'generate',
      requestId,
      prompt,
      projectId: activeProjectId,
    });
  };

  const handleCreateProject = () => {
    const newProject = createProject({
      name: 'New Project',
      description: 'AI-generated Roblox game',
      status: 'draft',
      code: generatedCode,
    });
    setActiveProjectId(newProject.id);
  };

  const handleOpenProject = (projectId: string) => {
    navigate(`${ROUTE_PATHS.EDITOR}?id=${projectId}`);
  };

  const handleDeleteProject = (projectId: string) => {
    deleteProject(projectId);
    if (activeProjectId === projectId) {
      setActiveProjectId(null);
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case ConnectionStatus.CONNECTED:
        return 'bg-green-500';
      case ConnectionStatus.CONNECTING:
        return 'bg-yellow-500';
      case ConnectionStatus.ERROR:
        return 'bg-red-500';
      default:
        return 'bg-muted';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case ConnectionStatus.CONNECTED:
        return 'Connected';
      case ConnectionStatus.CONNECTING:
        return 'Connecting';
      case ConnectionStatus.ERROR:
        return 'Connection Error';
      default:
        return 'Disconnected';
    }
  };

  return (
    <motion.div
      className="min-h-screen bg-background p-6"
      initial="hidden"
      animate="visible"
      variants={fadeInUp}
    >
      <div className="mx-auto max-w-7xl space-y-6">
        <motion.div
          className="flex items-center justify-between"
          variants={fadeInUp}
        >
          <div>
            <h1 className="text-4xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground mt-2">
              Build Roblox games with AI-powered generation
            </p>
          </div>
          <Button
            size="lg"
            onClick={handleCreateProject}
            disabled={!generatedCode}
            className="gap-2"
          >
            <Plus className="h-5 w-5" />
            Create Project
          </Button>
        </motion.div>

        <motion.div
          className="grid gap-6 md:grid-cols-3"
          variants={staggerContainer}
        >
          <motion.div variants={staggerItem}>
            <Card className="border-2">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Connection Status
                </CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <div
                    className={`h-3 w-3 rounded-full ${getStatusColor()} ${status === ConnectionStatus.CONNECTED ? 'animate-pulse' : ''}`}
                  />
                  <span className="text-2xl font-bold">{getStatusText()}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {status === ConnectionStatus.CONNECTED
                    ? 'Plugin ready for commands'
                    : 'Waiting for plugin connection'}
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={staggerItem}>
            <Card className="border-2">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Active Projects
                </CardTitle>
                <Folder className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{activeProjects.length}</div>
                <p className="text-xs text-muted-foreground mt-2">
                  {projects.length} total projects
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={staggerItem}>
            <Card className="border-2">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Generations Today
                </CardTitle>
                <Sparkles className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {generationHistory.filter(h => {
                    const today = new Date();
                    return h.timestamp.toDateString() === today.toDateString();
                  }).length}
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {generationHistory.filter(h => h.status === 'completed').length} completed
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        <motion.div
          className="grid gap-6 lg:grid-cols-2"
          variants={staggerContainer}
        >
          <motion.div variants={staggerItem} className="space-y-6">
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-accent" />
                  AI Game Generator
                </CardTitle>
                <CardDescription>
                  Describe your game and let AI generate the code
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AIPromptInterface
                  onGenerate={handleGenerate}
                  isGenerating={isGenerating}
                />
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-muted-foreground" />
                  Generation History
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {generationHistory.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No generations yet. Start by entering a prompt above.
                    </p>
                  ) : (
                    generationHistory.slice(0, 5).map((item) => (
                      <div
                        key={item.id}
                        className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                      >
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">
                            {item.prompt}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {formatTimestamp(item.timestamp)}
                          </p>
                        </div>
                        <Badge
                          variant={
                            item.status === 'completed'
                              ? 'default'
                              : item.status === 'error'
                              ? 'destructive'
                              : 'secondary'
                          }
                        >
                          {item.status}
                        </Badge>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={staggerItem}>
            <Card className="border-2 h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5 text-primary" />
                  Live Code Preview
                </CardTitle>
                <CardDescription>
                  Generated Lua code for your Roblox game
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[500px]">
                  {generatedCode ? (
                    <CodeEditor
                      code={generatedCode}
                      language="lua"
                      readOnly
                    />
                  ) : (
                    <div className="flex items-center justify-center h-full border-2 border-dashed rounded-lg">
                      <div className="text-center">
                        <Code className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <p className="text-sm text-muted-foreground">
                          Generated code will appear here
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {recentProjects.length > 0 && (
          <motion.div variants={fadeInUp}>
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Recent Projects</CardTitle>
                <CardDescription>
                  Your most recently updated projects
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  {recentProjects.map((project) => (
                    <ProjectCard
                      key={project.id}
                      project={project}
                      onOpen={() => handleOpenProject(project.id)}
                      onDelete={() => handleDeleteProject(project.id)}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <motion.div
          className="grid gap-6 md:grid-cols-2"
          variants={staggerContainer}
        >
          <motion.div variants={staggerItem}>
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full justify-start gap-2"
                  onClick={() => navigate(ROUTE_PATHS.PROJECTS)}
                >
                  <Folder className="h-4 w-4" />
                  View All Projects
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start gap-2"
                  onClick={() => navigate(ROUTE_PATHS.SETTINGS)}
                >
                  <Activity className="h-4 w-4" />
                  Connection Settings
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={staggerItem}>
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Getting Started</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
                    1
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Install Roblox Plugin</p>
                    <p className="text-xs text-muted-foreground">
                      Download and install the companion plugin in Roblox Studio
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
                    2
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Connect to Server</p>
                    <p className="text-xs text-muted-foreground">
                      Configure WebSocket connection in Settings
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
                    3
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Start Building</p>
                    <p className="text-xs text-muted-foreground">
                      Use AI prompts to generate game code instantly
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  );
}