import { useState, useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { Copy, Check, Code2, Clock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { formatTimestamp } from '@/lib/index'
import { fadeInUp, springPresets } from '@/lib/motion'
import { cn } from '@/lib/utils'

interface CodeEditorProps {
  code: string
  language?: string
  onChange?: (code: string) => void
  readOnly?: boolean
}

export function CodeEditor({ code, language = 'lua', onChange, readOnly = false }: CodeEditorProps) {
  const [copied, setCopied] = useState(false)
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date())
  const editorRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    if (code) {
      setLastUpdated(new Date())
      if (editorRef.current && !readOnly) {
        editorRef.current.scrollTop = editorRef.current.scrollHeight
      }
    }
  }, [code, readOnly])

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.error('Failed to copy code:', error)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (onChange && !readOnly) {
      onChange(e.target.value)
    }
  }

  const lines = code.split('\n')
  const lineCount = lines.length

  return (
    <motion.div
      variants={fadeInUp}
      initial="hidden"
      animate="visible"
      className="flex flex-col h-full bg-card rounded-xl border border-border overflow-hidden"
      style={{
        boxShadow: '0 8px 30px -6px color-mix(in srgb, var(--primary) 15%, transparent)'
      }}
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-muted/30">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Code2 className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-foreground">Code Editor</span>
          </div>
          <Badge variant="secondary" className="text-xs">
            {language.toUpperCase()}
          </Badge>
          {code && (
            <Badge variant="outline" className="text-xs flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {formatTimestamp(lastUpdated)}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">
            {lineCount} {lineCount === 1 ? 'line' : 'lines'}
          </span>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleCopy}
            disabled={!code}
            className="h-8 px-3"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 mr-1.5 text-accent" />
                <span className="text-xs">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 mr-1.5" />
                <span className="text-xs">Copy</span>
              </>
            )}
          </Button>
        </div>
      </div>

      <div
        ref={editorRef}
        className="flex-1 overflow-auto bg-card"
        style={{
          background: 'linear-gradient(135deg, var(--card) 0%, color-mix(in srgb, var(--card) 98%, var(--primary)) 100%)'
        }}
      >
        <div className="flex min-h-full">
          <div className="flex-shrink-0 py-4 px-3 bg-muted/20 border-r border-border select-none">
            {Array.from({ length: Math.max(lineCount, 20) }, (_, i) => (
              <div
                key={i + 1}
                className="text-xs text-muted-foreground text-right leading-6 font-mono"
              >
                {i + 1}
              </div>
            ))}
          </div>

          <div className="flex-1 relative">
            {readOnly ? (
              <pre className="p-4 text-sm font-mono leading-6 text-foreground whitespace-pre-wrap break-words">
                {code || (
                  <span className="text-muted-foreground italic">
                    No code generated yet. Use the AI prompt interface to generate code.
                  </span>
                )}
              </pre>
            ) : (
              <textarea
                ref={textareaRef}
                value={code}
                onChange={handleChange}
                className={cn(
                  'w-full h-full p-4 text-sm font-mono leading-6',
                  'bg-transparent text-foreground',
                  'resize-none outline-none',
                  'placeholder:text-muted-foreground placeholder:italic'
                )}
                placeholder="Start typing or generate code with AI..."
                spellCheck={false}
              />
            )}
          </div>
        </div>
      </div>

      {code && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={springPresets.gentle}
          className="px-4 py-2 border-t border-border bg-muted/20"
        >
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Character count: {code.length}</span>
            <span>Last updated: {lastUpdated.toLocaleTimeString()}</span>
          </div>
        </motion.div>
      )}
    </motion.div>
  )
}
