import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Home, LayoutDashboard, FolderOpen, Code, Settings, ChevronLeft, ChevronRight } from 'lucide-react';
import { ROUTE_PATHS } from '@/lib/index';
import { springPresets, fadeInUp } from '@/lib/motion';
import { ConnectionStatus } from '@/components/ConnectionStatus';
import { useWebSocket } from '@/hooks/useWebSocket';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface LayoutProps {
  children: React.ReactNode;
}

const navigationItems = [
  { path: ROUTE_PATHS.HOME, label: 'Home', icon: Home },
  { path: ROUTE_PATHS.DASHBOARD, label: 'Dashboard', icon: LayoutDashboard },
  { path: ROUTE_PATHS.PROJECTS, label: 'Projects', icon: FolderOpen },
  { path: ROUTE_PATHS.EDITOR, label: 'Editor', icon: Code },
  { path: ROUTE_PATHS.SETTINGS, label: 'Settings', icon: Settings },
];

export function Layout({ children }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { status } = useWebSocket();

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);
  const toggleMobileMenu = () => setMobileMenuOpen(!mobileMenuOpen);

  return (
    <div className="min-h-screen bg-background">
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={springPresets.gentle}
        className="fixed top-0 left-0 right-0 z-50 h-16 bg-card/80 backdrop-blur-md border-b border-border"
      >
        <div className="h-full px-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMobileMenu}
              className="lg:hidden"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={toggleSidebar}
              className="hidden lg:flex"
            >
              {sidebarOpen ? <ChevronLeft className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
            </Button>

            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Code className="h-5 w-5 text-primary-foreground" />
              </div>
              <h1 className="text-xl font-semibold tracking-tight">AI Roblox Builder</h1>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <ConnectionStatus status={status} />
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm lg:hidden"
            onClick={toggleMobileMenu}
          >
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              transition={springPresets.gentle}
              onClick={(e) => e.stopPropagation()}
              className="fixed top-16 left-0 bottom-0 w-64 bg-sidebar border-r border-sidebar-border overflow-y-auto"
            >
              <nav className="p-4 space-y-2">
                {navigationItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;

                  return (
                    <NavLink
                      key={item.path}
                      to={item.path}
                      onClick={toggleMobileMenu}
                      className={cn(
                        'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200',
                        isActive
                          ? 'bg-sidebar-accent text-sidebar-accent-foreground shadow-lg'
                          : 'text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground'
                      )}
                    >
                      <Icon className="h-5 w-5" />
                      <span className="font-medium">{item.label}</span>
                    </NavLink>
                  );
                })}
              </nav>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      <aside
        className={cn(
          'hidden lg:block fixed top-16 left-0 bottom-0 bg-sidebar border-r border-sidebar-border transition-all duration-300 overflow-y-auto z-30',
          sidebarOpen ? 'w-64' : 'w-20'
        )}
      >
        <nav className="p-4 space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;

            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={cn(
                  'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200',
                  isActive
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground shadow-lg'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground',
                  !sidebarOpen && 'justify-center'
                )}
              >
                <Icon className="h-5 w-5 flex-shrink-0" />
                {sidebarOpen && <span className="font-medium">{item.label}</span>}
              </NavLink>
            );
          })}
        </nav>

        {sidebarOpen && (
          <motion.div
            variants={fadeInUp}
            initial="hidden"
            animate="visible"
            className="absolute bottom-0 left-0 right-0 p-4 border-t border-sidebar-border"
          >
            <div className="flex items-center gap-3 px-4 py-3 rounded-lg bg-sidebar-accent/20">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-primary-foreground font-semibold">
                AI
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-sidebar-foreground truncate">AI Assistant</p>
                <p className="text-xs text-sidebar-foreground/60 truncate">Ready to build</p>
              </div>
            </div>
          </motion.div>
        )}
      </aside>

      <main
        className={cn(
          'pt-16 min-h-screen transition-all duration-300',
          'lg:pl-64',
          !sidebarOpen && 'lg:pl-20'
        )}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={springPresets.gentle}
          className="p-6"
        >
          {children}
        </motion.div>
      </main>
    </div>
  );
}