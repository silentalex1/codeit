import { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Loader2, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { springPresets, fadeInUp, staggerContainer, staggerItem } from '@/lib/motion';
import type { GenerationRequest } from '@/lib/index';

interface AIPromptInterfaceProps {
  onGenerate: (prompt: string) => void;
  isGenerating: boolean;
}

const examplePrompts = [
  'Create a parkour obby with 10 challenging stages',
  'Build a sword fighting arena with power-ups',
  'Make a racing game with boost pads and checkpoints',
  'Design a tycoon game with automated resource collection',
];

export function AIPromptInterface({ onGenerate, isGenerating }: AIPromptInterfaceProps) {
  const [prompt, setPrompt] = useState('');
  const maxLength = 500;

  const handleSubmit = () => {
    if (prompt.trim() && !isGenerating) {
      onGenerate(prompt.trim());
    }
  };

  const handleExampleClick = (example: string) => {
    setPrompt(example);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <motion.div
      variants={fadeInUp}
      initial="hidden"
      animate="visible"
      className="w-full space-y-6"
    >
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-accent" />
            <h3 className="text-lg font-semibold text-foreground">AI Game Generator</h3>
          </div>
          <Badge variant="secondary" className="text-xs">
            {prompt.length}/{maxLength}
          </Badge>
        </div>

        <div className="relative">
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value.slice(0, maxLength))}
            onKeyDown={handleKeyDown}
            placeholder="Describe your Roblox game idea in detail... (Cmd/Ctrl + Enter to generate)"
            className="min-h-[120px] resize-none bg-card border-border focus:border-accent transition-colors"
            disabled={isGenerating}
          />
          {isGenerating && (
            <div className="absolute inset-0 bg-background/50 backdrop-blur-sm rounded-lg flex items-center justify-center">
              <div className="flex items-center gap-2 text-accent">
                <Loader2 className="w-5 h-5 animate-spin" />
                <span className="text-sm font-medium">Generating...</span>
              </div>
            </div>
          )}
        </div>

        <Button
          onClick={handleSubmit}
          disabled={!prompt.trim() || isGenerating}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
          size="lg"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Generating Game Code...
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 mr-2" />
              Generate Game
            </>
          )}
        </Button>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="h-px flex-1 bg-border" />
          <span className="text-xs text-muted-foreground font-medium">Example Prompts</span>
          <div className="h-px flex-1 bg-border" />
        </div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 sm:grid-cols-2 gap-2"
        >
          {examplePrompts.map((example, index) => (
            <motion.button
              key={index}
              variants={staggerItem}
              onClick={() => handleExampleClick(example)}
              disabled={isGenerating}
              className="text-left p-3 rounded-lg bg-secondary/50 hover:bg-secondary border border-border hover:border-accent transition-all text-sm text-secondary-foreground disabled:opacity-50 disabled:cursor-not-allowed"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              transition={springPresets.snappy}
            >
              {example}
            </motion.button>
          ))}
        </motion.div>
      </div>

      {isGenerating && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={springPresets.gentle}
          className="p-4 rounded-lg bg-accent/10 border border-accent/20"
        >
          <div className="flex items-start gap-3">
            <div className="mt-0.5">
              <Loader2 className="w-5 h-5 text-accent animate-spin" />
            </div>
            <div className="flex-1 space-y-1">
              <p className="text-sm font-medium text-foreground">AI Processing</p>
              <p className="text-xs text-muted-foreground">
                Analyzing your prompt and generating Lua code for your Roblox game...
              </p>
            </div>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
