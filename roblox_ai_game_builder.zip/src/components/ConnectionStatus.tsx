import { motion } from "framer-motion";
import { Wifi, WifiOff, Loader2, AlertCircle } from "lucide-react";
import { ConnectionStatus as ConnectionStatusEnum } from "@/lib/index";
import { springPresets } from "@/lib/motion";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface ConnectionStatusProps {
  status: ConnectionStatusEnum;
  serverUrl?: string;
  connectedAt?: Date;
}

export function ConnectionStatus({ status, serverUrl, connectedAt }: ConnectionStatusProps) {
  const getStatusConfig = () => {
    switch (status) {
      case ConnectionStatusEnum.CONNECTED:
        return {
          icon: Wifi,
          label: "Connected",
          color: "bg-chart-3 text-white",
          pulseColor: "bg-chart-3",
          showPulse: true,
        };
      case ConnectionStatusEnum.CONNECTING:
        return {
          icon: Loader2,
          label: "Connecting",
          color: "bg-chart-4 text-white",
          pulseColor: "bg-chart-4",
          showPulse: true,
          animate: true,
        };
      case ConnectionStatusEnum.ERROR:
        return {
          icon: AlertCircle,
          label: "Error",
          color: "bg-destructive text-destructive-foreground",
          pulseColor: "bg-destructive",
          showPulse: false,
        };
      case ConnectionStatusEnum.DISCONNECTED:
      default:
        return {
          icon: WifiOff,
          label: "Disconnected",
          color: "bg-muted text-muted-foreground",
          pulseColor: "bg-muted-foreground",
          showPulse: false,
        };
    }
  };

  const config = getStatusConfig();
  const Icon = config.icon;

  const formatConnectionTime = () => {
    if (!connectedAt) return null;
    const now = new Date();
    const diff = now.getTime() - connectedAt.getTime();
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (hours > 0) {
      return `${hours}h ${minutes % 60}m`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`;
    } else {
      return `${seconds}s`;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={springPresets.gentle}
      className="flex items-center gap-3"
    >
      <div className="relative">
        <Badge
          className={cn(
            "flex items-center gap-2 px-3 py-1.5 font-medium transition-all",
            config.color
          )}
        >
          <Icon
            className={cn(
              "h-4 w-4",
              config.animate && "animate-spin"
            )}
          />
          <span>{config.label}</span>
        </Badge>

        {config.showPulse && (
          <motion.div
            className={cn(
              "absolute inset-0 rounded-full opacity-75",
              config.pulseColor
            )}
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.5, 0, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        )}
      </div>

      {status === ConnectionStatusEnum.CONNECTED && (
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={springPresets.snappy}
          className="flex flex-col text-xs"
        >
          {serverUrl && (
            <span className="text-muted-foreground font-mono truncate max-w-[200px]">
              {serverUrl}
            </span>
          )}
          {connectedAt && (
            <span className="text-muted-foreground">
              Uptime: {formatConnectionTime()}
            </span>
          )}
        </motion.div>
      )}
    </motion.div>
  );
}
