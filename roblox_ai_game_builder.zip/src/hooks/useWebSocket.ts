import { useState, useEffect, useRef, useCallback } from 'react';
import { ConnectionStatus, WebSocketClient } from '@/lib/index';

interface UseWebSocketReturn {
  status: ConnectionStatus;
  send: (data: any) => void;
  lastMessage: any;
  connect: () => void;
  disconnect: () => void;
}

export function useWebSocket(url: string = 'ws://localhost:8080'): UseWebSocketReturn {
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const [lastMessage, setLastMessage] = useState<any>(null);
  const clientRef = useRef<WebSocketClient | null>(null);

  useEffect(() => {
    const client = new WebSocketClient(url);
    clientRef.current = client;

    const unsubscribeStatus = client.onStatusChange((newStatus) => {
      setStatus(newStatus);
    });

    const unsubscribeMessage = client.onMessage((data) => {
      setLastMessage(data);
    });

    client.connect();

    return () => {
      unsubscribeStatus();
      unsubscribeMessage();
      client.disconnect();
    };
  }, [url]);

  const send = useCallback((data: any) => {
    if (clientRef.current) {
      try {
        clientRef.current.send(data);
      } catch (error) {
        console.error('Failed to send message:', error);
      }
    }
  }, []);

  const connect = useCallback(() => {
    if (clientRef.current) {
      clientRef.current.connect();
    }
  }, []);

  const disconnect = useCallback(() => {
    if (clientRef.current) {
      clientRef.current.disconnect();
    }
  }, []);

  return {
    status,
    send,
    lastMessage,
    connect,
    disconnect,
  };
}